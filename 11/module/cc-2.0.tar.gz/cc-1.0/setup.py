

from distutils.core import setup

setup(name='cc',version='1.0',description='cc module',author='cc',py_modules=['suba.aa','suba.bb','subb.cc','subb.dd'])



