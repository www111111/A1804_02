from distutils.core import setup
setup(name='carFactory',version='1.0',description='cc module',author='cc',py_modules=['简单工厂模式'])


