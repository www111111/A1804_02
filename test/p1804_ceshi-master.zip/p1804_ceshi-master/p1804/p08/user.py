# -*- coding: UTF-8 -*-
#定义姓名，注意字符串需要用引号
name='张三'
#定义年龄，注意年龄是整数
age=20

account=2423550286
nickName='大白'
xing_ming = "zhangsan"

#输出
print ("我叫 >>> ",name)
print ("我今年 >>> ",age)
print ("帐号是：>>> ",account)
leixing = type(age)
print ("age 的类型是 ", type(age))
print ("age 的类型是 ", leixing)

