
if 1 == 1:
    pass
elif 2 == 2:
    pass
else:
    pass
