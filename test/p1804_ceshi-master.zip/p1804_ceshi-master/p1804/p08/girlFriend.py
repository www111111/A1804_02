
#girl01 = 'meilv'
#girl02 = 'fuyou'
girl = "meilv"

if girl == 'meilv':
    print ("i do")
else girl == 'fuyou':
    print (" no ")


