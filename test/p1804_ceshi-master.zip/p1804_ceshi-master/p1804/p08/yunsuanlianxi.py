12/2+1
2*3
5-2
a=1
b=2
print ("a+b = ",a+b)
print ('x'*5)
print ('m'+5)
