
# 数据类型转换
'''
1. int --->   str
整数类型  装换成  字符串类型
'''
age = 20
# 错误是方式  (str)age
ageStr = str(age)

'''
2. str ---> int
字符串 转成  整数类型
'''
userId = '120110199009090121'
userIdInt = int(userId)
'''
3. str ---> float
4. float ---> str
5. bool ---> str
'''

