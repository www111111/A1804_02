#!/usr/bin/env python
#coding=utf-8
# 定义西瓜的单价 元/斤
price=3.8
# 西瓜的重量 几斤 几两
weight=2.9
# 多少钱
price_sum=price*weight - 0.5
#price_sum1 = price_sum-0.5
print ("您应当支付的 \n 金额是 ： ",price_sum)


