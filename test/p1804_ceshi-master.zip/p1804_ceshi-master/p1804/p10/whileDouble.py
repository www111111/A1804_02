
a = 1
while a<=10:
    print ('外层循环')

    nei = 1
    while nei <= 2:
        print ('---------------内循环')
        nei = nei+1

    a = a+1
