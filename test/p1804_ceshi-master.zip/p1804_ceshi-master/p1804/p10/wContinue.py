


'''
a = 1
while True:
    a = a+1
    if a%3 == 0:
        continue
    print ( '*' * a )
    if a == 50:
        break
'''

'''
*
**
***
****
1. while 10
2. print ('*' * 100)
'''
a = 1
while a<=10:
    print (a * "*")
    a = a+1

    if a>2:
        continue

    print ('^-^' * a)




