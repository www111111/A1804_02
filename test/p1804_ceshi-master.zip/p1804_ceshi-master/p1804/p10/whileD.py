
'''
while
while
    while
1
12
123
1234
12345
123456
1234567
'''
row = 1
while row < 10:
    #print (row, end="\t")
    #-----------------------
    a = 1
    while a <= row:
        print (a, end="\t")
        a = a+1
    #-----------------------
    row = row+1
    print ("\n")




