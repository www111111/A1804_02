
'''
while 循环

# while语句作用的范围是
# 下方相同缩进的 所有语句
while 循环条件：
    pass
    pass

循环条件：
1. 是否成立：  True / False
2. 条件判断控制   a 比较 b
'''

#-------------------------------
qiandao = 0 # 没有签到
xinqing = 'kaixin'
while qiandao < 10:
    print ("您未签到，请尽快去签到，否则要跪键盘 %d "% qiandao)
    qiandao = qiandao + 1





#----------------------------------
# True 始终成立
# Fasle 始终不成立
while False:
    print ("你应该签到了！")






