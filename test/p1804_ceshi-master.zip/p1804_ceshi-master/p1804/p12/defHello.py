
# 和每个小朋友打招呼

# 定义了一个函数，函数的名字是  sayHello()
# 函数的语句体： 函数名下边，相同缩进的所有语句
def sayHello():
    print ("-"*30)
    print ("life is shrot, you need python.")
    print ("-"*30)

def addSum():
    """这是一个求和的函数"""
    a = 1
    b = 2
    sum = a + b
    print (sum)



addSum()

'''
xinqing = input("心情如何：")
if xinqing == 'kaixin':
    sayHello()
    sayHello()
    sayHello()
else:
    print ("6666666")
'''


