
# while 1-10
i = 0
while True:
    i += 1
    print (i)
    if i == 10:
        break
