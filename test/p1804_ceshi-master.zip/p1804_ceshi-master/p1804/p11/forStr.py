
# 把字符串 ‘python’ 逐个字母输出
# for 循环
name = 'zhangsan'
for i in name:
    print ( i, end=" -> ")

print ('\n')

