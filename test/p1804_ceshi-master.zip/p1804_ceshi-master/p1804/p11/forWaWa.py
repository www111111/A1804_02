
# for 抓娃娃 if
'''
for i in range(1,7):
    t = int(input("请输入抓娃娃用了多长实际1～30s"))
    if t < 30:
        print ("恭喜你，抓娃娃成功。")
    else:
        print ("操作超时，自动抓取 失败。")
'''

# continue
for i in range(1,7):
    t = int(input("请输入抓娃娃用了多长实际1～30s"))
    if t < 30:
        print ("恭喜你，抓娃娃成功。")
        continue

    print ("操作超时，自动抓取 失败。")
    print ("操作超时，自动抓取 失败。")
    print ("操作超时，自动抓取 失败。")
    print ("操作超时，自动抓取 失败。")
    print ("操作超时，自动抓取 失败。")
    print ("操作超时，自动抓取 失败。")
    print ("操作超时，自动抓取 失败。")


