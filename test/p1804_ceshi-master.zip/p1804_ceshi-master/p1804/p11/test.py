
if sex == 'nv':
    pass
    if age > 60:
        pass
    else:

else:
    if age> 55:
        pass
    else:
        pass
    pass

if name = 'zhangsan':
    for x in name:
        print (x)
else:
    while True:
        print name

