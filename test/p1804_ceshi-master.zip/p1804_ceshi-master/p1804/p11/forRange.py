
#for 循环输出 1-10

for i in range(0,101,2):
    print(i)
    pass
print ('\n')
