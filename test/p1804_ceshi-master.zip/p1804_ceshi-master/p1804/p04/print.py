
while True:
	print 'hello girls'
