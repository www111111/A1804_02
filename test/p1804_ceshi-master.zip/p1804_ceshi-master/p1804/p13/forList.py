
numList = [1,21,3,4,5,76,2,23,12,3211]

print ('3号位置是：%d \t 8号位置是：%d。'% (numList[3], numList[8]))


for i in numList: # 遍历 列表
    print (i)




