
xinqing = input("是否开心:")

def hanhua(n):
    print((n+'\n')*10)

neirong = input('请输入喊叫的内容：')

if xinqing == 'k':
    hanhua(neirong)
else:
    hanhua(neirong)




