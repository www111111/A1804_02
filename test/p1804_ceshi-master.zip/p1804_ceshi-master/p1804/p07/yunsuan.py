a=8
b=3
result=a*b
print ("result = ", result)


