#coding=utf-8
print ("your are a good students!")
print ("你哈哦!")
