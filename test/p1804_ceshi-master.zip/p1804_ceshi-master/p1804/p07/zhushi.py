
#this is my story;
print ("10921&(*)(432jljsalfdkjfoia") #this note
#this is

while True:




print ("i love u")

'''
123
12l3kj12
sdalkfjdslakf
    ljfdlsakjf
        lkjfdsalfakja
            lkjfdsalfjk;

'''

"""

"""
