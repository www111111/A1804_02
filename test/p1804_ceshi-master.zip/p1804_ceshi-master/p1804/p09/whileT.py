
b = 10

# while 循环条件:
#   循环语句

while b > 6:
    print (" nihao mv ")
    b = b-1  # 9

#while True:  # True  False
#    print (" nihao mv ")
#    print (" nihao shuai guo ")


#1. while 循环结束
#2. while 循环条件 不成立
print ("=======================")


