# -*- coding:utf-8 -*-
print ("没有任何内容提示的 input")
a = input("")
print (""+a)

print ("增加提示信息的  input")
a = input("请输入您的姓名")
print (""+a)

