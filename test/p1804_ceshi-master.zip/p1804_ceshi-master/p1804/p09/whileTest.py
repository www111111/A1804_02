import random

a = random.randint(1,9)
print ("随机的数字是 %d " % (a) )

b = 10

if b > 20:  # True 成立  False 不成立
    pass
else:
    pass

print ("-------------")

# while 下方相同缩进范围内的,所有语句
while False: #不会进入 循环
    print ("")
    print ("")
    print ("")
    print ("")
    print ("")
    print ("")
    pass

print ("---------")

