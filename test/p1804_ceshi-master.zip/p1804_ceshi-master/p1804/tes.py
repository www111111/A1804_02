# -*- coding: UTF-8 -*-
a = '张三'
print ("  测试 这是 >>> %s " % a )
print (" {0} 测试 这是 >>> %s " . format(a) )

