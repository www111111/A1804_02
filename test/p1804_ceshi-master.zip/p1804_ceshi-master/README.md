# p1804_ceshi
# ��or create a new repository on the command line

```
echo "# p1804_ceshi" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin git@github.com:nmww/p1804_ceshi.git
git push -u origin master

```
# ��or push an existing repository from the command line
```
git remote add origin git@github.com:nmww/p1804_ceshi.git
git push -u origin master

```
# git push use

```
git add .
git commit -m 'yao jiaru de xinxi '
git push -u origin master

```



